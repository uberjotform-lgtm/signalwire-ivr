# SignalWire + Telegram IVR (Full, Twilio-style control)
1) Create SignalWire space, buy number. Note SW_PROJECT, SW_TOKEN, SW_SPACE.
2) Host this Node app (Replit/Render/VPS). Set env vars (see .env.example). `npm i && npm start`
3) In your SignalWire number -> Voice webhook (POST) = https://YOUR_BASE/sw/incoming
4) Telegram webhook: https://api.telegram.org/bot<TOKEN>/setWebhook?url=https://YOUR_BASE/tg/webhook
5) In Telegram: /call +2010XXXXXXX to start outbound call.
